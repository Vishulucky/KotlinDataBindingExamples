package com.kotlinexampledatabind

import android.databinding.DataBindingUtil
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.kotlinexampledatabind.databinding.ActivityMainBinding
import com.kotlinexampledatabind.viewmodel.User

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        val activitybinding:ActivityMainBinding = DataBindingUtil.setContentView(this,R.layout.activity_main)

        val user = User(" John","Martin")
        activitybinding.setVariable(BR.usermodel,user)
        activitybinding.executePendingBindings()




    }
}
