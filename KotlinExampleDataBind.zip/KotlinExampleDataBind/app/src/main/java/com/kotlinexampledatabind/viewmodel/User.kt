package com.kotlinexampledatabind.viewmodel

/**
 * Created by lenovo on 3/6/2018.
 */
class User
{

    var firstname:String? = ""
    var lastname:String? = ""

    constructor(firstname: String?, lastname: String?) {
        this.firstname = firstname
        this.lastname = lastname
    }
}